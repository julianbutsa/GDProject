﻿using UnityEngine;
using System.Collections;

public class PowerReceiver : MonoBehaviour {
	public bool receivingPower;
	// Use this for initialization
	void Start () {
		receivingPower = false;
	}
	
	// Update is called once per frame
	void Update () {
	}
}
